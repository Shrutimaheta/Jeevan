from django.db import models
from django.conf import settings  
from care.models import Hospital

# Create your models here.
class Receptionist(models.Model):
    id = models.AutoField(primary_key=True)
    hospital = models.ForeignKey(Hospital, on_delete=models.CASCADE, related_name='receptionists')
    user = models.ForeignKey (settings.AUTH_USER_MODEL, on_delete=models.CASCADE, limit_choices_to={'role': 'receptionist'})
    full_name = models.CharField(max_length=255)
    contact_number = models.CharField(max_length=15)
    gender = models.CharField(max_length=10, choices=[
        ('Male', 'Male'),
        ('Female', 'Female'),
        ('Other', 'Other'),
    ])
    password = models.CharField(max_length=128)
    def _str_(self):
        return self.full_name
