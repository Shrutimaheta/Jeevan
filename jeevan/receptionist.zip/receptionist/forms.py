from django import forms
from .models import Receptionist  # Update this import to match your app structure

class ReceptionistAdminForm(forms.ModelForm):
    class Meta:
        model = Receptionist
        exclude = ['full_name', 'password']  # Fields to exclude from the form
